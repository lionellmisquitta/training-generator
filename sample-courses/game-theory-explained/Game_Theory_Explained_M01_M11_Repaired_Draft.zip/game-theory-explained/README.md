# Game Theory Explained — 11-module repaired **draft** (M09–M11 updated)

**Not publication-ready.** This complete educational draft has 11 modules, 22 lessons and 88 assessment questions. Structural validator and the Training Generator v2.3 `release_gate.py --phase draft` pass. Its publication gate still blocks, correctly, because revised modules lack new independent hash-bound review, no named human publication approval has been supplied, and current-player browser acceptance is unavailable.

## What changed after Claude's independent review

- **Module 09:** eliminated the stray fixed-entry-cost value of 950. The teaching problem and calculations consistently use 800.
- **Module 10:** includes executable Python checks for logit/fairness utilities, Hawk-Dove population dynamics and Old/New adoption thresholds. Replaced the audit-penalty application with a true frequency-dependent compatibility-bridge scenario moving the tipping point from 4/7 to 0.40.
- **Module 11:** adds an executable two-by-two mixed-equilibrium solver with audit-cost comparative statics, plus a supplier-type/effort payoff calculation and verification sensitivity. The capstone explicitly references the inspection-game treatment in M03 L2 rather than silently recycling it.

Modules 1–8 remain byte-for-byte identical and retain Claude's accepted independent reviews. Earlier Claude reviews of Modules 9–11 remain **historical only** because their hashes no longer match.

## Contents

- `course.html` / `course.json`: regenerated playable course and canonical merge; source is explicitly labelled draft.
- `modules/`: original module files (M01–M08) and repaired module files (M09–M11).
- `index.json`, `CONTINUE_HERE.json`, `self-reviews/`: checkpoint state and hash-bound author's review records.
- `reviews/m01.json`–`m08.json`: original hash-bound independent review records for unchanged modules.
- `historical-evidence/`: superseded checkpoint, old reviews of changed modules, and original browser screenshots/logs.
- `qa/verify_m10_m11.py`, `qa/NEW_MODULE_QA.json`, `qa/REPAIR_QA.json`: numerical, structural and change-verification evidence.
- `evidence/new-draft-gate.log`: actual PASS; `evidence/new-publish-gate-expected-fail.log`: documented publication block.

## Verify

Extract the Training Generator v2.3 skill and run:

```bash
python scripts/validate_course.py /path/to/course/course.json
python /path/to/course/qa/verify_m10_m11.py
python scripts/release_gate.py --course /path/to/course --phase draft
python scripts/release_gate.py --course /path/to/course --phase publish
```

The final command must fail until independent re-review of M09–M11, real browser QA, module-level human approvals and course publication authorization are genuinely completed. No synthetic approvals have been created.
