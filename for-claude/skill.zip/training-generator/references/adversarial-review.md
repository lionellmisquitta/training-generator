# Adversarial quality review

Self-review is not independent review. A PASS requires work actually performed, not persuasive prose. A required `not_executed` check blocks draft self-verification; optional additional checks may explicitly record `not_executed` without being silently omitted. Record limitations honestly and do not fabricate tool runs, link checks, browser observations, approvals or historical checkpoint evidence.

## Seven-step falsification procedure — perform for EVERY authored module
1. **Recalculate all mathematical and quantitative claims** independently, including intermediate steps, units, payoff/cost timing, boundary cases, equilibrium assumptions and sensitivity outcomes. Record inputs, formulas, results and how these were independently checked.
2. **Run executable code and numerical assertions** when runtime is available; compare code outputs with lesson narrative. If execution is impossible, mark the relevant verification `not_executed` and block release rather than inventing a PASS.
3. **Map each learning objective** to concrete teaching evidence (lesson heading or exact derivation/example/lab/question). Verify a learner could actually perform the stated objective.
4. **Challenge worked examples and applications for originality**, comparing strategic/game mechanism, actors, timing, information, best responses and decision outcome against *every prior lesson*, labs, code, quizzes and other applications. Replacing nouns and numbers does not count as different.
5. **Audit every quiz** by solving without using its marked key, reviewing distractors, technical terminology, answer-length cues, key positions and shortest-correct cues; compare question numbers with labs and narrative.
6. **Audit source provenance and learner experience**: link titles, source credibility, access status and licensing only when live-checked; test visuals, accessibility, sequencing, level and prerequisites with stated evidence. Never describe an unchecked resource as free.
7. **Verify artifacts and real execution evidence**: canonical merged JSON, byte-for-byte builder HTML, checkpoint and hash bindings, test logs, actual browser QA (only if performed), independent review and named human approval (only if obtained). An unperformed browser test cannot pass.

## Required eight named checks
Every `self_adversarial` module review must supply `module_sha256`, `review_type`, `overall`, `checks`, and `findings`. The `checks` array must contain **at least eight** entries with these required ids: `mathematics`, `examples`, `assessment`, `application`, `sources`, `duplication`, `semantic_originality`, `objective_coverage`. Each PASS must give specific, reproducible evidence, ideally calculations, cited source locations, exact lesson/question identifiers, comparisons, or test commands and outputs. The shared programmatic validator rejects identical or near-duplicate evidence across checks (punctuation ignored; >=80% shared distinct-word sets), missing/failed required checks, any check marked fail, and required checks marked not_executed; it permits optional extra checks marked not_executed with honest limitations. Each required PASS needs at least 12 evidence words, but distinct prose or a word count is not proof of a performed review. Independently inspect the claimed computations, exact references and output. Token overlap is a screening heuristic, not proof of independent thought; an unrelated short generic sentence may also require a clearer, more specific rewrite.

## Check results (values of `checks[].result`)
- `pass`: required work genuinely performed and check-specific evidence recorded; independent verification still needed.
- `fail`: a defect identified; repair and repeat the relevant checks. Any check with `fail` blocks self-verification.
- `not_executed`: not performed or tool unavailable. If it is one of the eight required checks, self-verification fails. Optional extra checks such as `browser_qa` may report `not_executed` without blocking the draft self-review, but must not be described as completed. Publication still requires actual browser QA.

## Checkpoint module states (not check results)
- `planned`: module not submitted.
- `needs_repair`: failed independent review; repair and resubmit via checkpoint engine.
- `review_pending`: submitted module awaiting self-review; independent review is still separate.
- `self_verified`: all eight required self-review checks passed; still not independently reviewed.
- `review_passed`: separate hash-bound passing independent review exists; no human approval yet.
- `approved`: explicitly human-approved reviewed module; not permission to publish the entire course.

For each lesson, separately preserve evidence of objective mapping, independent calculations and counterexamples, lab-versus-code-versus-quiz comparisons, application mechanism distinction, source access status, and answer-option biases. Do not claim independent verification by relabelling self-review. A passing independent review must have a hash binding, a reviewer identity different from the author, a findings array, and **no unresolved critical, high, or blocking finding**. The checkpoint and release gate enforce the same independent-review contract; a failing review with unresolved findings is valid as a failure and routes the module to repair. Public publication additionally requires independent review for every module, human approval and actual browser QA.
