#!/usr/bin/env python3
"""Arithmetic and consistency checks for revised M10/M11 hypothetical examples.
This is deterministic arithmetic QA, not independent pedagogical review.
"""
import json, math, pathlib, re, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
checks=[]
def eq(name,actual,expected,tol=1e-9):
    passed=math.isclose(actual,expected,rel_tol=tol,abs_tol=tol)
    checks.append({'name':name,'actual':actual,'expected':expected,'pass':passed})
    if not passed: raise AssertionError(f'{name}: {actual} != {expected}')
def yes(name,result):
    checks.append({'name':name,'actual':bool(result),'expected':True,'pass':bool(result)})
    if not result: raise AssertionError(name)
# M10 L1: inequity aversion and conditional logit.
eq('m10l1 responder 30/70 alpha .8',30-.8*(70-30),-2)
eq('m10l1 responder 40/60 alpha .8',40-.8*(60-40),24)
eq('m10l1 responder threshold',80/2.6,30.76923076923077)
eq('m10l1 utility at 31',31-.8*(69-31),.6)
eq('m10l1 proposer 69/31 beta .25',69-.25*(69-31),59.5)
eq('m10l1 proposer 60/40 beta .25',60-.25*(60-40),55)
eq('m10l1 quiz payoff 35 alpha .5',35-.5*(65-35),20)
eq('m10l1 logit odds for 8 versus 6',math.exp(math.log(2)*(8-6)),4)
eq('m10l1 logit choice probability',4/(1+4),.8)
eq('m10l1 lab 120 alpha .6 threshold',72/2.2,32.7272727273,tol=1e-8)
eq('m10l1 lab 120 alpha 1 threshold',120/3,40)
eq('m10l1 lab conditional logit',2/(1+2),2/3)
eq('m10l1 on-call B payoff old',6-.5*(14-6),2)
eq('m10l1 on-call B payoff redesigned',8-.5*(12-8),6)
# M10 L2: Hawk-Dove, conventions, governance.
eq('m10l2 Hawk v Hawk',(6-10)/2,-2)
eq('m10l2 Dove v Dove',6/2,3)
eq('m10l2 Hawk-Dove interior share',6/10,.6)
eq('m10l2 replicator .2',.2*(1-.2)*(3-5*.2),.32)
eq('m10l2 replicator .8',.8*(1-.8)*(3-5*.8),-.16)
eq('m10l2 lab V4 C10 share',4/10,.4)
eq('m10l2 quiz derivative .4',.4*(1-.4)*(3-5*.4),.24)
eq('m10l2 standards threshold',8/14,4/7)
eq('m10l2 New at .4',11*.4-2,2.4)
eq('m10l2 Old at .4',6-3*.4,4.8)
eq('m10l2 New at .7',11*.7-2,5.7)
eq('m10l2 Old at .7',6-3*.7,3.9)
eq('m10l2 new quiz threshold',8/16,.5)
eq('m10l2 bridge New at .5',7*.5+2,5.5)
eq('m10l2 bridge Old at .5',6-3*.5,4.5)
eq('m10l2 bridge threshold',4/10,.4)
eq('m10l2 old New at .5',11*.5-2,3.5)
eq('m10l2 bridge New at .3',7*.3+2,4.1)
eq('m10l2 bridge Old at .3',6-3*.3,5.1)
# M11 L1 audit, contracts, congestion.
eq('m11l1 audit mix p',3/8,.375)
eq('m11l1 compliance mix q',4/6,2/3)
p=3/8;q=2/3
eq('m11l1 supplier complies payoff',3+p,3.375)
eq('m11l1 supplier cuts payoff',6-7*p,3.375)
eq('m11l1 buyer audits payoff',1+2*q,7/3)
eq('m11l1 buyer skips payoff',8*q-3,7/3)
eq('m11l1 cost plus one q',3/6,.5)
eq('m11l1 new quiz cut -2 p',3/9,1/3)
eq('m11l1 new quiz skip cut -5 q',6/8,.75)
eq('m11l1 new quiz audit cost plus two q',2/6,1/3)
eq('m11l1 quality high contract profit',10-4,6)
eq('m11l1 shortcut p .8',10-1-.8*5,5)
eq('m11l1 shortcut p .4',10-1-.4*5,7)
eq('m11l1 detection threshold',(10-1-6)/5,.6)
eq('m11l1 two Peak payoff',12-3,9)
eq('m11l1 three Peak payoff',12-3*2,6)
eq('m11l1 congestion two Peak total',9+9+7,25)
eq('m11l1 congestion all Peak total',3*6,18)
eq('m11l1 congestion all Offpeak total',3*7,21)
# M11 L2 supplier selection, contract, options, hold-up.
eq('m11l2 Low effort incentive bonus',20+70-60,30)
eq('m11l2 High effort incentive bonus',20+100-60,60)
eq('m11l2 Low participation bonus',25+70-60,35)
eq('m11l2 High participation bonus',35+100-60,75)
eq('m11l2 high profit bonus 76',60+76-100,36)
eq('m11l2 low profit bonus 76',60+76-70,66)
eq('m11l2 shortcut payoff',60-40,20)
eq('m11l2 buyer inclusive payoff',170-60-76,34)
eq('m11l2 selective buyer Low payoff',170-60-70,40)
eq('m11l2 selective buyer expectation',.6*40+.4*20,32)
eq('m11l2 High with 90% detection',60+.9*76-100,28.4)
eq('m11l2 High with 95% detection',60+.95*76-100,32.2)
eq('m11l2 High new outside 38 bonus',38+100-60,78)
eq('m11l2 new buyer bonus 78',170-60-78,32)
eq('m11l2 new prior selective expected value',.7*40+.3*20,34)
eq('m11l2 bundle Nash early',(8-2)*(3-2),6)
eq('m11l2 bundle Nash staged',(6-2)*(7-2),20)
eq('m11l2 bundle Nash rushed',(5-2)*(4-2),6)
eq('m11l2 hold-up max late fee',100-5,95)
eq('m11l2 hold-up realized publisher profit',100-95-30,-25)
eq('m11l2 hold-up precommitment publisher profit',100-40-30,30)
# Source data and non-mathematical structural checks.
modules=[json.loads((ROOT/f'modules/m{i:02}.json').read_text()) for i in (10,11)]
expected={
'Bounded Rationality and Fairness':[2,0,3,1],
'Evolution, Conventions and Coordination':[2,0,1,3],
'Building and Testing a Strategic Game':[3,0,2,1],
'Capstone: Partnership, Procurement and Negotiation':[1,3,0,2],
}
for m in modules:
  for lesson in m['lessons']:
    t=lesson['title'];qs=lesson['questions']
    yes(t+' expected quiz position map', [x['answer'] for x in qs]==expected[t])
    yes(t+' exactly four distinct answers each',all(len(q['choices'])==4 and len(set(q['choices']))==4 for q in qs))
    yes(t+' explanation >=600',sum(len(x.split()) for x in lesson['explanation'] if isinstance(x,str))>=600)
    yes(t+' examples 80+ substantive prose',all(sum(len(z.split()) for z in e['walkthrough'])>=80 for e in lesson['examples']))
    yes(t+' application >=150',len(lesson['practical_application']['scenario'].split())>=150)
    yes(t+' objectives taught and assessed',len(lesson['objectives'])>=2 and len(qs)==4)
    longest=sum(len(q['choices'][q['answer']])>max(len(v) for i,v in enumerate(q['choices']) if i!=q['answer']) for q in qs)
    shortest=sum(len(q['choices'][q['answer']])<min(len(v) for i,v in enumerate(q['choices']) if i!=q['answer']) for q in qs)
    yes(t+' no longest-correct bias',longest<=1)
    yes(t+' no shortest-correct bias',shortest<=1)
    yes(t+' resources specific',len(lesson['resources'])>=2 and len(set(z['url'] for z in lesson['resources']))==len(lesson['resources']))
# Detect verbatim 10-grams across lessons in the course; log evidence rather than declaring semantic originality.
course=json.loads((ROOT/'course.json').read_text())
seen={};cross=[]
for m in course['modules']:
 for lesson in m['lessons']:
  title=lesson['title'];base=' '.join(x if isinstance(x,str) else x.get('text','') for x in lesson['explanation'] if isinstance(x,str) or x.get('type')=='text'); toks=re.findall(r"[\w']+",base.lower())
  grams=set(tuple(toks[i:i+10]) for i in range(max(0,len(toks)-9)))
  for gram in grams:
   if gram in seen and seen[gram]!=title and (title in expected or seen[gram] in expected):
    cross.append({'first':seen[gram],'second':title,'phrase':' '.join(gram)})
   else:seen.setdefault(gram,title)
yes('no repeated 10-grams between new and other lesson explanations',not cross)
output={'result':'pass','scope':'M10-M11 deterministic calculations and structural screens only','assertions_passed':len(checks),'checks':checks,'cross_lesson_verbatim_overlap':cross,'limitations':['Not a separate independent academic review','Qualitative assertions and strategic mechanism originality require critical reviewer scrutiny','External link existence checked via source discovery, not continuous access or licensing']}
(ROOT/'qa/NEW_MODULE_QA.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(f"PASS {len(checks)} assertions, explanations 4/4, new quiz positions verified")
