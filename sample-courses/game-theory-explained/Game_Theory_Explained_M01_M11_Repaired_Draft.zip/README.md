# Game Theory Explained — complete curriculum, editorially corrected

**Status: published source code / sample-course candidate; formal educational release gate still pending.**

The course contains **11 modules, 22 lessons, and 88 assessment questions**. The course owner authorized publication on 2026-10-27 and the completed course is available in the public GitHub sample-courses directory.

## Final editorial correction

In Module 9, Lesson 2, changed **“Without an advance commitment, It expects”** to **“Without an advance commitment, it expects”**. Only this capitalization byte changed in M09; no numerical explanation or question was altered.

Claude's latest October 27 reviews passed all of M09, M10 and M11, with the one low-severity capitalization finding in M09. The original M09 independent review was bound to `ea0ca6db586c0393245d9e8e3b5b0ade66646e69644950028cead0ead7f77519`; the corrected M09 SHA-256 is `40fd9af3bc1657b587b92e1a09704fa2920c924996a0abc8862f673415799f9a`. Therefore the old review is **historical**, not a hash-bound independent approval of the corrected text.

## Current verification

- Content and code: structural validator PASS; new-module numerical audit PASS; draft release gate PASS.
- Human approval: user explicitly authorized publication; 10 unchanged modules carry recorded human approval.
- Module 9: self-verified; new independent review pending for its corrected hash.
- Browser: seven actual headless Chromium interaction checks passed; `file://` execution is blocked by this runtime, so full offline/browser acceptance is **not** claimed.
- Publication gate: **FAIL**, pending the current-hash M09 review, completion of browser QA and final authorization using the checkpoint engine. These have **not** been waived or fabricated.

## Files

`course.html` is the generated standalone player; `course.json` is editable content; `modules/`, `index.json`, `self-reviews/`, `reviews/`, and `CONTINUE_HERE.json` preserve the canonical sources and checkpoint. `historical-evidence/` includes superseded review and source hashes; `PUBLICATION_READINESS.json` records current status.

To reproduce, run Training Generator v2.3 `scripts/release_gate.py --course PATH --phase draft`. Do not present the course as fully independent-approved until `--phase publish` passes.
