# Shared chat / Codex orchestration (checkpoint engine v0.9)

The checkpoint engine is the sole writer of CONTINUE_HERE.json. The authoring host (chat, Codex, Claude Code) does not hand-edit state.

## Chat entrypoints and persistent files
- **Create a course:** establish audience, original syllabus/index, planned modules and working folder; initialize durable checkpoint state before any module submission.
- **Continue my course:** inspect `CONTINUE_HERE.json` with `checkpoint.py status`, validate referenced hashes and resume the next valid module without recreating prior approvals.
- **Show progress:** report each module's real checkpoint state, authored lesson count, independent review/approval and open issues; never confuse authored with approved.
- Persist the canonical index, per-module JSON, reviews, checkpoint, merged JSON and generated HTML in a durable course folder that survives session limits; archive inputs and explicit generation/version details.

## Legacy course safety warning
Prior mass-generated Grade 2, Game Theory and AI Engineering lessons failed independent content review. **Do not accept or migrate them directly into approved checkpoints.** Recover preserved sources with their actual hashes, run fresh adversarial reviews and keep historical missing-evidence disclosures. Only genuine new approvals may advance publication status.

## Draft-production lane

`planned -> review_pending -> self_verified` using the following commands:

```bash
python scripts/checkpoint.py init --course courses/my-course --index syllabus.json
python scripts/checkpoint.py submit --course courses/my-course --module module-1.json --author ChatGPT
python scripts/checkpoint.py selfreview --course courses/my-course --report self-review.json
python scripts/checkpoint.py status --course courses/my-course
```

The `submit --module` input must be a **compact single-module JSON** with root `{ "title": "Index module title", "lessons": [ ... ] }`, not a `{ "modules": [ ... ] }` wrapper; the merge tool adds the wrapper internally. The lesson title/order must match the index.

The draft release gate **fails** if an authored module remains `review_pending`; submit alone is not permission to deliver a checked draft. For exploratory checks while review is pending, use `validate_course.py` and label the output unverified. Do not reduce the adult release depth minimum of 600 explanation-only words with command-line options.

After self-verified, the next module may be submitted. All earlier submitted module bytes and SHA-256 hashes are checked on every operation. Self-review report requires `module_sha256`, `review_type:"self_adversarial"`, `overall:"pass"`, `checks` with result (`pass` or `not_executed`) and supporting `evidence`, and `findings`. All eight required named checks must pass with distinct, specific evidence of work performed. Any `fail` check (required or optional), required `not_executed` check, identical/near-duplicate evidence (80% distinct-word overlap) or unresolved blocking finding prevents completion and the draft release gate. Optional additional checks such as browser QA may honestly report `not_executed` during draft self-review. The same shared validator is used in both checkpoint submission and release gating. `not_executed` must never be described as passed. Self-review is not independent review and grants no publication permission.

## Separate independent review / publication lane

```bash
python scripts/checkpoint.py review --course courses/my-course --module-id m01 --report claude-review.json
python scripts/checkpoint.py approve --course courses/my-course --module-id m01 --approver 'Actual human approver'
```

External review JSON: `{"module_sha256":"exact-content-sha256", "verdict":"pass", "reviewer":"Claude Code", "findings":[]}`. Reviewer identity is user-provided metadata, not cryptographic proof of independence. The engine rejects matching author/reviewer names, incorrect hashes and a passing verdict containing an unresolved critical, high or blocking finding. A failing verdict may correctly retain unresolved findings. Checkpoint and release verification share this rule. Approval requires an independent PASS and named human approver. Chat may continue drafting modules while external review trails, without auto-approving any module. A failed independent review marks that module `needs_repair`; if later modules exist, further new drafting is blocked, but re-submission of the failed module is permitted. The block clears only after an actual new independent PASS review of the repaired module.

## Recovery

Restore the course directory and call `status` before doing anything else. For historical manually edited state files, create a NEW checkpoint state by `init` using the original syllabus and sequentially `submit` and `selfreview` each module using its existing, byte-for-byte preserved source file and authentic self-review report. Never synthesize a historical self-review PASS or silently promote missing reviews. Keep the original files unchanged in the migration archive. Never regenerate authored lessons merely to repair their state.

No automatic background process, external model access, GitHub sync or browser QA is implied by this engine. Publish authorization is separate. Before publish, every module must contain named `approved_by`, the checkpoint must contain named `publication_approver`, and `BROWSER_QA.json` must contain `result:"pass"`, `tested_by`, nonempty `evidence`, and `player_sha256` matching the current canonical `course.html`. These fields are provenance checks, not cryptographic proof that browser testing was genuinely performed. Invalid or unreadable packaged course JSON returns a clean `FAIL:` error instead of a traceback.
