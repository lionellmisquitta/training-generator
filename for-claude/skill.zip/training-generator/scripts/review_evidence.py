#!/usr/bin/env python3
"""One fail-closed self-review contract shared by checkpoint and release gate.

This checks evidence structure and provenance, NOT the truth of the claims.
"""
import re

REQUIRED_CHECKS = frozenset({
    'mathematics', 'examples', 'assessment', 'application',
    'sources', 'duplication', 'semantic_originality', 'objective_coverage'
})
CHECK_RESULTS = frozenset({'pass', 'fail', 'not_executed'})
BLOCKING_SEVERITIES = frozenset({'critical', 'high', 'blocking'})
MIN_PASS_EVIDENCE_WORDS = 12


def normalized(value):
    return ' '.join(str(value).casefold().split())


def word_count(value):
    return len(re.findall(r'\b\w+\b', value, re.UNICODE))


def evidence_words(value):
    """Punctuation-insensitive evidence fingerprint; preserve check-id underscores separately."""
    return re.findall(r'[^\W_]+', str(value).casefold(), re.UNICODE)


def similar_evidence(left, right):
    """Catch word-for-word boilerplate with minor padding; not semantic verification."""
    a, b = set(evidence_words(left)), set(evidence_words(right))
    return bool(a and b) and len(a & b) / len(a | b) >= 0.80


def validate_findings(findings, verdict, context):
    if not isinstance(findings, list):
        raise ValueError(f'{context} findings must be an array')
    for i, finding in enumerate(findings, 1):
        if not isinstance(finding, dict):
            raise ValueError(f'Malformed {context} finding {i}')
        if (verdict == 'pass' and normalized(finding.get('severity', '')) in BLOCKING_SEVERITIES
                and finding.get('resolved') is not True):
            raise ValueError(f'Unresolved blocking {context} finding {i}')


def validate_independent_review(report, expected_hash, author, require_pass=False):
    """Single checkpoint/release contract for reviews. Text identities are not proof of independence."""
    if not isinstance(report, dict):
        raise ValueError('Independent review must be a JSON object')
    if report.get('module_sha256') != expected_hash:
        raise ValueError('Independent review hash mismatch')
    verdict = report.get('verdict')
    if verdict not in ('pass', 'fail'):
        raise ValueError('Independent review verdict must be pass or fail')
    reviewer = report.get('reviewer')
    if not isinstance(reviewer, str) or not reviewer.strip():
        raise ValueError('Independent reviewer identity required')
    reviewer_key = normalized(reviewer)
    author_key = normalized(author or '')
    if reviewer_key in ('self', 'author') or (author_key not in ('', 'unspecified') and reviewer_key == author_key):
        raise ValueError('Independent reviewer identity required and must differ from author')
    validate_findings(report.get('findings'), verdict, 'independent-review')
    if require_pass and verdict != 'pass':
        raise ValueError('Independent PASS missing')
    return True


def validate_self_review(report, expected_hash):
    """Raise ValueError for invalid evidence. Optional unexecuted work remains visible."""
    if not isinstance(report, dict):
        raise ValueError('Self-review must be a JSON object')
    if report.get('module_sha256') != expected_hash:
        raise ValueError('Self-review hash mismatch')
    if report.get('review_type') != 'self_adversarial' or report.get('overall') != 'pass':
        raise ValueError('Passing self_adversarial review required')
    checks = report.get('checks')
    if not isinstance(checks, list):
        raise ValueError('Self-review checks must be an array')
    seen = set()
    evidence_seen = []
    passed_required = set()
    for position, check in enumerate(checks, 1):
        if not isinstance(check, dict):
            raise ValueError(f'Self-review check {position} must be an object')
        check_id = normalized(check.get('id', check.get('name', '')))
        if not check_id:
            raise ValueError(f'Self-review check {position} missing id')
        if check_id in seen:
            raise ValueError(f'Duplicate self-review check id: {check_id}')
        seen.add(check_id)
        outcome = check.get('result')
        if outcome not in CHECK_RESULTS:
            raise ValueError(f'Invalid result for {check_id}: use pass, fail, not_executed')
        evidence = check.get('evidence')
        if not isinstance(evidence, str) or not evidence.strip():
            raise ValueError(f'Missing evidence for {check_id}')
        if any(similar_evidence(evidence, prior) for prior in evidence_seen):
            raise ValueError('Duplicate or near-duplicate self-review evidence across checks: ' + check_id)
        evidence_seen.append(evidence)
        if outcome == 'fail':
            raise ValueError(f'Failed self-review check: {check_id}')
        if outcome == 'not_executed':
            if check_id in REQUIRED_CHECKS:
                raise ValueError(f'Required self-review check not executed: {check_id}')
            # Optional checks can be honestly disclosed as not_executed.
            continue
        if word_count(evidence) < MIN_PASS_EVIDENCE_WORDS:
            raise ValueError(f'Insufficient evidence for {check_id}: at least {MIN_PASS_EVIDENCE_WORDS} words')
        if check_id in REQUIRED_CHECKS:
            passed_required.add(check_id)
    missing = REQUIRED_CHECKS - passed_required
    if missing:
        raise ValueError('Eight substantive PASS checks required: ' + ', '.join(sorted(missing)))
    validate_findings(report.get('findings'), 'pass', 'self-review')
    return True
