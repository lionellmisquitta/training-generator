#!/usr/bin/env python3
"""Checkpoint-to-release contract tests, including honest negative disclosures."""
import argparse
import contextlib
import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from checkpoint import cmd
from release_gate import main as release_main
from merge_course import merge
from build_course import build
from review_evidence import REQUIRED_CHECKS


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class CheckpointContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        example = Path(__file__).resolve().parent.parent/'references/example-lesson.json'
        course = json.loads(example.read_text())
        course['modules'] = course['modules'][:1]
        course['modules'][0]['lessons'] = course['modules'][0]['lessons'][:1]
        lesson = course['modules'][0]['lessons'][0]
        for i, q in enumerate(lesson['questions']):
            q['answer'] = [2, 0, 3, 1][i % 4]
            q['choices'] = [f'Plausible alternative number {j} with full context' for j in range(4)]
        self.module_data = course['modules'][0]
        index = json.loads(json.dumps(course))
        index['modules'][0]['lessons'] = [{'title': lesson['title'], 'status': 'planned'}]
        self.index_src = self.root/'syllabus.json'
        self.index_src.write_text(json.dumps(index))
        self.module_src = self.root/'draft-module.json'
        self.module_src.write_text(json.dumps(self.module_data))
        self.call('init', index=str(self.index_src))
        self.call('submit', module=str(self.module_src), author='ChatGPT')

    def tearDown(self):
        self.temp.cleanup()

    def call(self, action, **kwargs):
        arguments = dict(action=action, course=str(self.root), index=None, module=None,
                         report=None, approver=None, author=None, module_id=None)
        arguments.update(kwargs)
        with contextlib.redirect_stdout(io.StringIO()):
            return cmd(argparse.Namespace(**arguments))

    def state(self):
        return json.loads((self.root/'CONTINUE_HERE.json').read_text())

    def report(self, extra=(), changes=None):
        # Varied synthetic evidence for CONTRACT TESTS only. Never use as actual course review.
        examples = {
            'mathematics': 'Fixture arithmetic: independently multiplied 7 by 9 to obtain 63, then verified the inverse division 63 by 7 yields 9.',
            'examples': 'Fixture walkthrough inspection: the opening bargaining example identifies reservation values, a rejected offer, and the resulting feasible agreement.',
            'assessment': 'Fixture assessment inspection: four choice indices were enumerated individually, and each distractor was independently checked for ambiguous wording.',
            'application': 'Fixture scenario inspection: the real-world decision changes actor incentives through switching cost rather than simply renaming the earlier payoff matrix.',
            'sources': 'Fixture bibliography inspection: source identifiers were checked against declared document titles, with online accessibility expressly left unverified.',
            'duplication': 'Fixture originality inspection: adjacent module walkthrough texts were compared sentence by sentence for verbatim reuse and unexplained repetition.',
            'semantic_originality': 'Fixture mechanism comparison: the two situations differ in available strategic moves, information disclosure timing, and feasible response options.',
            'objective_coverage': 'Fixture syllabus trace: objective one maps to a computation exercise while objective two maps to a contrasting explanation and assessment question.'
        }
        checks = [{'id': check, 'result': 'pass', 'evidence': examples[check]}
                  for check in sorted(REQUIRED_CHECKS)]
        checks += list(extra)
        if changes:
            changes(checks)
        return {'module_sha256': self.state()['modules'][0]['sha256'],
                'review_type': 'self_adversarial', 'overall': 'pass',
                'checks': checks, 'findings': []}

    def write_report(self, report):
        path = self.root/'selfreview-input.json'
        path.write_text(json.dumps(report))
        return str(path)

    def selfreview(self, report):
        self.call('selfreview', report=self.write_report(report))

    def create_canonical(self):
        index = json.loads((self.root/'index.json').read_text())
        course = merge(index, [{'modules': [self.module_data]}])
        (self.root/'course.json').write_text(json.dumps(course))
        with contextlib.redirect_stdout(io.StringIO()):
            build(self.root/'course.json', self.root/'course.html')

    def prepare_publish_fixture(self, stale_browser_hash=False):
        self.selfreview(self.report())
        self.create_canonical()
        review_path = self.root/'independent-pass.json'
        review_path.write_text(json.dumps({'module_sha256': self.state()['modules'][0]['sha256'],
                                           'verdict': 'pass', 'reviewer': 'Claude', 'findings': []}))
        self.call('review', report=str(review_path), module_id='m01')
        state = self.state()
        state['modules'][0]['status'] = 'approved'
        state['modules'][0]['approved_by'] = 'Human test fixture owner'
        state['publication_approved'] = True
        state['publication_approver'] = 'Human test fixture owner'
        (self.root/'CONTINUE_HERE.json').write_text(json.dumps(state))
        qa = {'result': 'pass', 'tested_by': 'Named independent test operator',
              'evidence': 'Synthetic QA metadata used only to test release-gate integrity logic.',
              'player_sha256': '0'*64 if stale_browser_hash else sha(self.root/'course.html')}
        (self.root/'BROWSER_QA.json').write_text(json.dumps(qa))

    def test_publish_requires_named_approval_metadata(self):
        self.prepare_publish_fixture()
        state = self.state()
        del state['modules'][0]['approved_by']
        del state['publication_approver']
        (self.root/'CONTINUE_HERE.json').write_text(json.dumps(state))
        errors, _ = release_main(self.root, 'publish', 600)
        self.assertTrue(any('approved_by identity missing' in e for e in errors), errors)
        self.assertTrue(any('publication_approver missing' in e for e in errors), errors)

    def test_publish_rejects_stale_browser_qa_hash(self):
        self.prepare_publish_fixture(stale_browser_hash=True)
        errors, _ = release_main(self.root, 'publish', 600)
        self.assertTrue(any('player_sha256 missing or mismatched' in e for e in errors), errors)

    def test_adult_minimum_cannot_be_waived_with_cli_option(self):
        self.selfreview(self.report())
        self.create_canonical()
        errors, _ = release_main(self.root, 'draft', 1)
        self.assertTrue(any('cannot weaken the gate' in e for e in errors), errors)

    def test_review_pending_is_not_a_draft_release(self):
        self.create_canonical()
        errors, _ = release_main(self.root, 'draft', 600)
        self.assertTrue(any('self-review required before draft release' in e for e in errors), errors)

    def test_honest_extra_browser_not_executed_is_accepted_end_to_end(self):
        extra = {'id': 'browser_qa', 'result': 'not_executed',
                 'evidence': 'No browser was available, so accessibility and visual interaction were not tested.'}
        self.selfreview(self.report(extra=[extra]))
        self.assertEqual(self.state()['modules'][0]['status'], 'self_verified')
        self.create_canonical()
        errors, _ = release_main(self.root, 'draft', 600)
        self.assertEqual(errors, [], errors)
        errors, _ = release_main(self.root, 'publish', 600)
        self.assertTrue(errors, 'A draft cannot count as a published course')

    def test_duplicate_evidence_rejected_by_checkpoint(self):
        report = self.report()
        repeated = report['checks'][0]['evidence']
        for check in report['checks']:
            check['evidence'] = repeated
        with self.assertRaisesRegex(ValueError, 'Duplicate or near-duplicate self-review evidence'):
            self.selfreview(report)

    def test_duplicate_evidence_tamper_rejected_by_release_gate(self):
        self.selfreview(self.report())
        self.create_canonical()
        stored = self.root/'self-reviews/m01.json'
        data = json.loads(stored.read_text())
        data['checks'][1]['evidence'] = data['checks'][0]['evidence']
        stored.write_text(json.dumps(data))
        errors, _ = release_main(self.root, 'draft', 600)
        self.assertTrue(any('Duplicate or near-duplicate self-review evidence' in e for e in errors), errors)

    def test_required_not_executed_is_rejected(self):
        def change(checks):
            checks[0]['result'] = 'not_executed'
        with self.assertRaisesRegex(ValueError, 'Required self-review check not executed'):
            self.selfreview(self.report(changes=change))

    def test_optional_failed_check_is_rejected(self):
        extra = {'id': 'browser_qa', 'result': 'fail',
                 'evidence': 'The browser testing process failed and the interactive player is broken.'}
        with self.assertRaisesRegex(ValueError, 'Failed self-review check'):
            self.selfreview(self.report(extra=[extra]))

    def test_invalid_check_result_is_rejected(self):
        extra = {'id': 'browser_qa', 'result': 'self_verified',
                 'evidence': 'This is a module state rather than a valid result for this check.'}
        with self.assertRaisesRegex(ValueError, 'Invalid result'):
            self.selfreview(self.report(extra=[extra]))

    def test_missing_findings_is_rejected(self):
        report = self.report()
        del report['findings']
        with self.assertRaisesRegex(ValueError, 'findings must be an array'):
            self.selfreview(report)

    def test_blocking_finding_is_rejected(self):
        report = self.report()
        report['findings'] = [{'severity': 'high', 'resolved': False, 'description': 'Incorrect result'}]
        with self.assertRaisesRegex(ValueError, 'Unresolved blocking self-review finding'):
            self.selfreview(report)

    def test_failed_independent_review_can_be_repaired_and_clears_block(self):
        self.selfreview(self.report())
        failed = self.root/'independent-fail.json'
        failed.write_text(json.dumps({'module_sha256': self.state()['modules'][0]['sha256'],
                                      'verdict': 'fail', 'reviewer': 'Claude', 'findings': []}))
        self.call('review', report=str(failed), module_id='m01')
        state = self.state()
        self.assertEqual(state['modules'][0]['status'], 'needs_repair')
        # Emulate a later already-authored module causing a forward-work block.
        state['blocked_by_review'] = 'm01'
        (self.root/'CONTINUE_HERE.json').write_text(json.dumps(state))
        self.call('submit', module=str(self.module_src), author='ChatGPT')
        self.selfreview(self.report())
        passed = self.root/'independent-pass.json'
        passed.write_text(json.dumps({'module_sha256': self.state()['modules'][0]['sha256'],
                                      'verdict': 'pass', 'reviewer': 'Claude', 'findings': []}))
        self.call('review', report=str(passed), module_id='m01')
        self.assertEqual(self.state()['modules'][0]['status'], 'review_passed')
        self.assertNotIn('blocked_by_review', self.state())


    def test_punctuation_only_variation_cannot_fake_eight_distinct_checks(self):
        report = self.report()
        repeated = 'Calculations were independently confirmed against every figure in the working example, and all results agree with assertions.'
        for i, check in enumerate(report['checks']):
            check['evidence'] = repeated + ('.' * (i + 1))
        with self.assertRaisesRegex(ValueError, 'Duplicate or near-duplicate'):
            self.selfreview(report)
        self.assertEqual(self.state()['modules'][0]['status'], 'review_pending')

    def test_appending_a_check_name_cannot_fake_eight_distinct_checks(self):
        report = self.report()
        repeated = 'Every lesson passage was checked against the original syllabus and findings were recorded with numeric test details and exact links.'
        for check in report['checks']:
            check['evidence'] = repeated + ' for ' + check['id'].replace('_', ' ') + '.'
        with self.assertRaisesRegex(ValueError, 'Duplicate or near-duplicate'):
            self.selfreview(report)

    def test_near_duplicate_evidence_tamper_fails_at_release_gate(self):
        self.selfreview(self.report())
        self.create_canonical()
        path = self.root/'self-reviews/m01.json'
        report = json.loads(path.read_text())
        report['checks'][1]['evidence'] = report['checks'][0]['evidence'] + ' for examples.'
        path.write_text(json.dumps(report))
        errors, _ = release_main(self.root, 'draft', 600)
        self.assertTrue(any('near-duplicate' in x for x in errors), errors)

    def test_independent_pass_with_unresolved_critical_finding_rejected_without_transition(self):
        self.selfreview(self.report())
        bad = self.root/'invalid-independent.json'
        bad.write_text(json.dumps({'module_sha256': self.state()['modules'][0]['sha256'],
                                   'verdict': 'pass', 'reviewer': 'Claude',
                                   'findings': [{'severity': 'critical', 'resolved': False, 'details': 'Incorrect theorem'}]}))
        with self.assertRaisesRegex(ValueError, 'Unresolved blocking independent-review finding'):
            self.call('review', report=str(bad), module_id='m01')
        self.assertEqual(self.state()['modules'][0]['status'], 'self_verified')
        self.assertIsNone(self.state()['modules'][0]['review'])

    def test_independent_pass_with_unresolved_high_finding_rejected(self):
        self.selfreview(self.report())
        bad = self.root/'high-review.json'
        bad.write_text(json.dumps({'module_sha256': self.state()['modules'][0]['sha256'],
                                   'verdict': 'pass', 'reviewer': 'Claude',
                                   'findings': [{'severity': 'high', 'resolved': False}]}))
        with self.assertRaisesRegex(ValueError, 'Unresolved blocking'):
            self.call('review', report=str(bad), module_id='m01')

    def test_independent_review_modified_after_acceptance_fails_release(self):
        self.prepare_publish_fixture()
        path = self.root/'reviews/m01.json'
        review = json.loads(path.read_text())
        review['findings'] = [{'severity': 'critical', 'resolved': False}]
        path.write_text(json.dumps(review))
        errors, _ = release_main(self.root, 'publish', 600)
        self.assertTrue(any('Unresolved blocking independent-review finding' in e for e in errors), errors)

    def test_failed_independent_review_with_unresolved_finding_is_accepted_as_failure(self):
        self.selfreview(self.report())
        bad = self.root/'fail-with-finding.json'
        bad.write_text(json.dumps({'module_sha256': self.state()['modules'][0]['sha256'],
                                   'verdict': 'fail', 'reviewer': 'Claude',
                                   'findings': [{'severity': 'critical', 'resolved': False}]}))
        self.call('review', report=str(bad), module_id='m01')
        self.assertEqual(self.state()['modules'][0]['status'], 'needs_repair')

    def test_nonblocking_independent_finding_may_remain_open(self):
        self.selfreview(self.report())
        caution = self.root/'caution.json'
        caution.write_text(json.dumps({'module_sha256': self.state()['modules'][0]['sha256'],
                                       'verdict': 'pass', 'reviewer': 'Claude',
                                       'findings': [{'severity': 'low', 'resolved': False, 'description': 'Minor style issue'}]}))
        self.call('review', report=str(caution), module_id='m01')
        self.assertEqual(self.state()['modules'][0]['status'], 'review_passed')

    def test_shortest_and_longest_thresholds_are_both_40_percent(self):
        self.create_canonical()
        data = json.loads((self.root/'course.json').read_text())
        lesson = data['modules'][0]['lessons'][0]
        for q in lesson['questions'][:2]:
            q['choices'][q['answer']] = 'Short'
        changed = data['modules'][0]
        module_file = self.root/'modules/m01.json'
        module_file.write_text(json.dumps(changed))
        state = self.state()
        state['modules'][0]['sha256'] = sha(module_file)
        (self.root/'CONTINUE_HERE.json').write_text(json.dumps(state))
        index = json.loads((self.root/'index.json').read_text())
        merged = merge(index, [{'modules': [changed]}])
        (self.root/'course.json').write_text(json.dumps(merged))
        with contextlib.redirect_stdout(io.StringIO()):
            build(self.root/'course.json', self.root/'course.html')
        self.selfreview(self.report())
        errors, _ = release_main(self.root, 'draft', 600)
        self.assertTrue(any('shortest-correct bias 2/4' in e for e in errors), errors)


if __name__ == '__main__':
    unittest.main()
