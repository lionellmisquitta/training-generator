#!/usr/bin/env python3
"""Adversarial regression suite: every corrupted fixture must be rejected."""
import json,tempfile,unittest,sys,hashlib
from pathlib import Path
from release_gate import main
from build_course import build
from merge_course import merge
from validate_course import validate

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class ReleaseGateTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        example=Path(__file__).resolve().parent.parent/'references/example-lesson.json'
        data=json.loads(example.read_text());data['modules']=data['modules'][:1]
        data['modules'][0]['lessons']=data['modules'][0]['lessons'][:1]
        lesson=data['modules'][0]['lessons'][0];lesson['questions'][0]['choices'][lesson['questions'][0]['answer']]='Okay'
        # Existing specimen is intentionally imperfect; modify only the fixture's test questions.
        for i,q in enumerate(lesson['questions']):
            q['answer']=([2,0,3,1][i%4]);q['choices']=[f'Plausible alternative {j} is the result' for j in range(4)]
        self.lesson=lesson;self.index=json.loads(json.dumps(data));self.index['modules'][0]['lessons']=[{'title':lesson['title'],'status':'planned'}]
        (self.root/'index.json').write_text(json.dumps(self.index))
        (self.root/'modules').mkdir();self.module=self.root/'modules/m01.json';self.module.write_text(json.dumps(data['modules'][0]))
        check_ids=('mathematics','examples','assessment','application','sources','duplication','semantic_originality','objective_coverage')
        evidence_by_check = {
            'mathematics': 'Synthetic computation record: six times eight was independently recalculated as forty eight, with reverse division confirming the input factors.',
            'examples': 'Synthetic example record: the bargaining walkthrough specifies both parties outside options, their first offer, and the observed acceptance outcome.',
            'assessment': 'Synthetic quiz record: each response option was examined against the problem statement, and distractors were classified by the misconception represented.',
            'application': 'Synthetic application record: real decisions alter timing and incentives rather than simply changing the names or payoffs shown in the primary example.',
            'sources': 'Synthetic references record: bibliographic descriptions were matched with their source titles, while unavailable live hyperlink tests were disclosed separately.',
            'duplication': 'Synthetic repetition record: lesson narratives were scanned for copied complete sentences and duplicate claims appearing under differently titled exercises.',
            'semantic_originality': 'Synthetic structure record: one mechanism involves signaling private knowledge, while a later mechanism involves simultaneous production quantity commitments.',
            'objective_coverage': 'Synthetic mapping record: skill target one connects to the derivation, and skill target two connects to the worked practice problem.'
        }
        report={'module_sha256':sha(self.module),'review_type':'self_adversarial','overall':'pass',
                'checks':[{'id':cid,'result':'pass','evidence':evidence_by_check[cid]} for cid in check_ids],
                'findings':[]}
        (self.root/'self-reviews').mkdir()
        (self.root/'self-reviews/m01.json').write_text(json.dumps(report))
        (self.root/'CONTINUE_HERE.json').write_text(json.dumps({'course_title':data['title'],'modules':[{'id':'m01','title':data['modules'][0]['title'],'status':'self_verified','artifact':'modules/m01.json','sha256':sha(self.module),'self_review':'self-reviews/m01.json'}],'publication_approved':False}))
        full=merge(self.index,[{'modules':[data['modules'][0]]}]);(self.root/'course.json').write_text(json.dumps(full));build(self.root/'course.json',self.root/'course.html')
    def tearDown(self):self.tmp.cleanup()
    def test_good_draft(self):
        errors,_=main(self.root,'draft',600)
        self.assertFalse(errors,errors)
    def test_validator_is_pure(self):
        before=(self.root/'course.json').read_text()
        data=json.loads(before); snapshot=json.dumps(data,sort_keys=True)
        validate(data)
        self.assertEqual(json.dumps(data,sort_keys=True),snapshot)
    def test_invalid_course_json_fails_cleanly_without_traceback(self):
        (self.root/'course.json').write_text('{ broken json')
        errors, _ = main(self.root, 'draft', 600)
        self.assertTrue(any('course.json unreadable or invalid JSON' in e for e in errors), errors)

    def test_empty_course_json_fails_cleanly_without_traceback(self):
        (self.root/'course.json').write_text('')
        errors, _ = main(self.root, 'draft', 600)
        self.assertTrue(any('course.json unreadable or invalid JSON' in e for e in errors), errors)

    def test_empty_array_course_json_fails_canonical_comparison(self):
        (self.root/'course.json').write_text('[]')
        errors, _ = main(self.root, 'draft', 600)
        self.assertTrue(any('course.json differs from canonical merge' in e for e in errors), errors)

    def test_malformed_json_cli_outputs_fail_not_traceback(self):
        import subprocess
        (self.root/'course.json').write_text('{broken')
        completed = subprocess.run([sys.executable, str(Path(__file__).with_name('release_gate.py')),
                                    '--course', str(self.root), '--phase', 'draft'],
                                   capture_output=True, text=True)
        self.assertNotEqual(completed.returncode, 0)
        self.assertIn('FAIL: course.json unreadable or invalid JSON', completed.stdout)
        self.assertNotIn('Traceback', completed.stderr)

    def test_missing_checkpoint(self):
        (self.root/'CONTINUE_HERE.json').unlink();errors,_=main(self.root,'draft',600);self.assertTrue(any('CONTINUE_HERE' in x for x in errors))
    def test_stale_module_hash(self):
        self.module.write_text(self.module.read_text()+' ');errors,_=main(self.root,'draft',600);self.assertTrue(any('hash mismatch' in x for x in errors))
    def test_changed_merged_json(self):
        p=self.root/'course.json';data=json.loads(p.read_text());data['description']='Unreviewed change';p.write_text(json.dumps(data));errors,_=main(self.root,'draft',600);self.assertTrue(any('canonical merge' in x for x in errors))
    def test_changed_html(self):
        p=self.root/'course.html';p.write_text(p.read_text()+'<!-- tampered -->');errors,_=main(self.root,'draft',600);self.assertTrue(any('byte-identical' in x for x in errors))
    def test_publish_without_review(self):
        errors,_=main(self.root,'publish',600);self.assertTrue(any('approval' in x for x in errors))
    def refresh_module(self, data):
        self.module.write_text(json.dumps(data))
        state=json.loads((self.root/'CONTINUE_HERE.json').read_text())
        state['modules'][0]['sha256']=sha(self.module)
        report_path=self.root/'self-reviews/m01.json'
        report=json.loads(report_path.read_text());report['module_sha256']=sha(self.module);report_path.write_text(json.dumps(report))
        (self.root/'CONTINUE_HERE.json').write_text(json.dumps(state))
        full=merge(self.index,[{'modules':[data]}])
        (self.root/'course.json').write_text(json.dumps(full))
        build(self.root/'course.json',self.root/'course.html')
    def test_shortest_correct_detected(self):
        data=json.loads(self.module.read_text())
        for q in data['lessons'][0]['questions']:
            q['choices'][q['answer']]='Yes'
        self.refresh_module(data)
        errors,_=main(self.root,'draft',600)
        self.assertTrue(any('shortest-correct bias' in error for error in errors),errors)
    def test_position_skew_detected(self):
        data=json.loads(self.module.read_text())
        for q in data['lessons'][0]['questions']:
            q['answer']=2
        self.refresh_module(data)
        errors,_=main(self.root,'draft',600)
        self.assertTrue(any('answer-position skew' in error for error in errors),errors)
    def test_self_review_insufficient_evidence(self):
        evidence_by_check = {
            'mathematics': 'Synthetic computation record: six times eight was independently recalculated as forty eight, with reverse division confirming the input factors.',
            'examples': 'Synthetic example record: the bargaining walkthrough specifies both parties outside options, their first offer, and the observed acceptance outcome.',
            'assessment': 'Synthetic quiz record: each response option was examined against the problem statement, and distractors were classified by the misconception represented.',
            'application': 'Synthetic application record: real decisions alter timing and incentives rather than simply changing the names or payoffs shown in the primary example.',
            'sources': 'Synthetic references record: bibliographic descriptions were matched with their source titles, while unavailable live hyperlink tests were disclosed separately.',
            'duplication': 'Synthetic repetition record: lesson narratives were scanned for copied complete sentences and duplicate claims appearing under differently titled exercises.',
            'semantic_originality': 'Synthetic structure record: one mechanism involves signaling private knowledge, while a later mechanism involves simultaneous production quantity commitments.',
            'objective_coverage': 'Synthetic mapping record: skill target one connects to the derivation, and skill target two connects to the worked practice problem.'
        }
        report={'module_sha256':sha(self.module),'review_type':'self_adversarial','overall':'pass',
        'checks':[{'id':i,'result':'pass','evidence':'This is only a vague statement and lacks enough details.'} for i in ('mathematics','examples','assessment','application','sources','duplication','semantic_originality','objective_coverage')]}
        (self.root/'self-reviews').mkdir(exist_ok=True);(self.root/'self-reviews/m01.json').write_text(json.dumps(report))
        state=json.loads((self.root/'CONTINUE_HERE.json').read_text())
        state['modules'][0].update(status='self_verified',self_review='self-reviews/m01.json')
        (self.root/'CONTINUE_HERE.json').write_text(json.dumps(state))
        errors,_=main(self.root,'draft',600)
        self.assertTrue(any('Insufficient evidence' in error for error in errors),errors)
    def test_duplicate_example(self):
        d=json.loads(self.module.read_text());ex=d['lessons'][0]['examples'][0]['walkthrough'];piece=ex[0] if isinstance(ex,list) else ex
        d['lessons'][0]['explanation'].append(piece)
        self.module.write_text(json.dumps(d));state=json.loads((self.root/'CONTINUE_HERE.json').read_text());state['modules'][0]['sha256']=sha(self.module);(self.root/'CONTINUE_HERE.json').write_text(json.dumps(state));report_path=self.root/'self-reviews/m01.json';report=json.loads(report_path.read_text());report['module_sha256']=sha(self.module);report_path.write_text(json.dumps(report));
        full=merge(self.index,[{'modules':[d]}]);(self.root/'course.json').write_text(json.dumps(full));build(self.root/'course.json',self.root/'course.html')
        errors,_=main(self.root,'draft',600);self.assertTrue(any('copied' in x for x in errors),errors)
if __name__=='__main__':unittest.main()
