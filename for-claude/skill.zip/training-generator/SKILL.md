---
name: training-generator
description: Create, deepen, revise, validate and package interactive educational courses and lessons as offline HTML5 players. Use this skill whenever the user mentions a course, curriculum, syllabus, lesson, module, training, learning content, assessment bank or quiz, or uploads a course package (index.json, modules/, CONTINUE_HERE.json, course.json, course.html) — even if they just say 'review this' or 'continue my course'. Covers syllabus-based courses, rigorous adult technical education, age-appropriate lessons, narrated visual scene demonstrations, resumable one-module checkpoints, mandatory adversarial self-verification, and Claude acting as the independent hash-bound reviewer of modules authored in ChatGPT or Codex.
---

# Training Generator

**Host note (Claude / Claude Code edition):** the same files, scripts and state transitions apply in every host. In this host Claude is usually the *independent reviewer* of modules authored elsewhere; when Claude is the author, it may self-verify but never write its own independent review. Scripts live under this skill's `scripts/` folder; run them with `python3 <skill-path>/scripts/<script>.py`.

Build genuinely teachable courses, not outlines or decorative pages. Work module by module rather than compressing a long course into one shallow generation pass.

## Workflow
1. Identify learner, scope, target depth, syllabus basis, outcomes and offline needs; infer defaults when safe.
2. Design the full module/lesson index. Represent ungenerated lessons as `status:"planned"`; set root `status:"draft"` until all lessons are complete.
3. Read `references/teaching-quality.md`, `references/university-sources.md` and `references/course-schema.md`. Model the JSON on `references/example-lesson.json`.
4. Never use a slot-filled lesson factory: author **one complete coherent module per checkpoint** (split its lessons into separate passes when needed); keep the remainder planned. Research primary university materials and papers first; log source-specific links and evidence limits. Generate original graduate-depth lessons in one module JSON at a time, with mathematical derivations, real code, nontrivial worked steps and labs when appropriate. Preserve source provenance and distinguish verified links from suggested resources. Never invent source checks.
5. Reject cross-lesson duplication of prose, lab, pitfalls, visual sequences, code and question prompts. Run `python scripts/validate_course.py path/to/course.json`, repair every failure and investigate every quality warning rather than targeting the minimum, and check objective answer keys and technical accuracy separately.
6. Validate merged courses (module parts are inputs to merge, not standalone root courses). For large courses use `python scripts/merge_course.py index.json module1.json module2.json > course.json`, then run `python scripts/build_course.py course.json output.html`. The offline player shows the full index including disabled planned lessons, visual scene cues, browser speech, a resources pane and shuffled Practice Time questions.
7. Test the HTML in a browser if a browser harness is available. Otherwise report **static validation only — not browser-tested**. Deliver HTML, editable JSON, and a concise disclosure of unimplemented media and missing lessons.

## When handed a course package for independent review (Claude host)
1. Unzip; confirm `CONTINUE_HERE.json`, `index.json`, `modules/`, `self-reviews/`, `course.json`, `course.html` are present. If the checkpoint is missing, stop: report it and ask for a package built through `checkpoint.py` — do not review loose files as if they were checkpointed.
2. Run `python3 scripts/release_gate.py --course <dir> --phase draft`. Report every FAIL line verbatim.
3. Review each module at its exact SHA-256: recompute every number, run every code block, solve every quiz without the key, map objectives to teaching, compare applications against the lesson's own examples for a different game form, check lab/quiz/code-assert numbers differ, note link access status only if checked.
4. Write `reviews/mNN.json` per module: `{"module_sha256": "<sha>", "verdict": "pass"|"fail", "reviewer": "Claude", "findings": [{"severity": ..., "location": ..., "detail": ..., "resolved": false}]}`. A `pass` must carry no unresolved critical/high/blocking finding. Deliver the files; the user records them with `checkpoint.py review --module-id mNN`.
5. Never approve, never set `publication_approved`, never write a self-review for a module Claude did not author.

## Shared chat / Codex orchestration
Read `references/orchestration.md` before creating, continuing, reviewing or approving a course. Use `scripts/checkpoint.py` for the same durable state transitions in both hosts when local execution is available. Advance the draft-generation lane after `selfreview` PASS using the checkpoint script; never promote a module to independently reviewed or approved without separate independent review and human approval. Chat can author and validate directly; Codex is optional, not a requirement for functional users. External provider review is only available if actually configured; otherwise export the review package and keep `review_pending`.

## Scale without losing quality
For large courses, keep a master index with planned lessons; write and validate one module at a time. Merge module JSONs with `scripts/merge_course.py` into a single validated course JSON; do not concatenate manually. The renderer accepts a single merged JSON file. Never label an outline a completed course. For full-course asks, preserve the complete planned index and deliver only the individually-authored lessons achieved in this pass; do not synthesize dozens of repetitive bodies.

## Honesty and boundaries
- Browser system speech may sound robotic and may be unavailable; this Player does **not** integrate Chatterbox, Qwen3-TTS, neural audio packaging, timestamp synchronization or word-level highlighting.
- Visual scenes advance on completed browser speech segments. They are simple interactive visual illustrations, not fully choreographed educational animation.
- HTTPS URL checks validate shape only; online availability and license rights require independent checks.
- The Skill contains no local model weights or execution environment; installed Skills depend on available host tools. Keep human voice quality and multimedia upgrades as future requirements, not delivered features.
- Treat AI-authored educational content as unverified until reviewed. Never claim compliance with a named school's official syllabus without its actual source.
- Correctness, browser support, question quality, reference validity and teaching effectiveness require checks beyond this simple structural validator.

## Optional applied practice (all disciplines)
Use `practical_application` only when a concrete applied example materially improves learning. It takes `title`, `scenario_title`, and `scenario` (at least 150 substantive words when present). Choose a subject-appropriate title: corporate decision for executive game theory, listening/performance for jazz, drawing exercise for art, experiment or real engineering case for technical study. The deprecated `corporate_application` field is accepted only for legacy content. Never invent business payoffs for unrelated subjects. A genuinely worked application must teach the subject's practice rather than repeat the lesson's own examples.

## Hard release gates (mandatory)
- **Do not publish solely because `validate_course.py` says PASS. The draft release gate requires all authored modules to have completed valid self-review; `review_pending` does not pass.** Execute `scripts/release_gate.py --course PATH --phase draft` on a checkpoint directory before any draft delivery, and `--phase publish` before presenting anything as publication-ready.
- `release_gate.py` rebuilds from canonical index/module sources; verifies hashes, checkpoint, review evidence and byte-identical player output. Any mismatch is FAIL. Do not copy walkthroughs into explanations or use a forked player.
- Failures require fixes and a rerun, not waived warnings, self-proclaimed review, or a manual rewrite of `CONTINUE_HERE.json`.
- For adult lessons, genuine *explanation-only* text must meet at least 600 words (a higher configured target is allowed), not by copying worked examples, applications, labs or questions into it. Never count application prose toward explanation depth.
- Self-review is not independent review. In particular, source verification, math correctness, semantic example originality, citation accuracy, accessibility and browser QA require evidence or explicit `not_executed` status. The script cannot establish all of these automatically. Evidence deduplication detects identical and near-duplicate prose but cannot verify claims are true.
- For public release, require independent hash-bound passing review, named human approval for every module and the course, plus genuine browser QA tied to the exact HTML player SHA-256; missing or stale evidence blocks release.

## Mandatory adversarial quality gate
Before claiming self-verification, execute the seven-step falsification procedure in `references/adversarial-review.md` and document all eight required checks with reproducible evidence. A check labelled PASS without performed verification is a failure of process. A required `not_executed` check blocks self-verification; optional extra checks (for example, browser QA) may honestly report `not_executed` during drafting, but publication still requires actual browser QA; never infer review or publication approval from an automated structural PASS.

## Regression defenses against superficially correct lessons
- An applied case must change the mechanism or decision, not merely reskin a worked example with new names, amounts or industries; manually explain the distinct game form.
- Map each objective to demonstrated derivation, worked example, exercise or assessment, and document coverage evidence.
- Compare lab, quiz, and executable assertion values; challenge independence and conceptual novelty, not simply numerical differences.
- Never label an online reference accessible or free without a real link/access check; use neutral resource labels when status is unknown.
- Run `python -m unittest discover -s scripts -p "test_*.py" -q` after modifying this skill and the actual `release_gate.py --phase draft` on each course; a green unit suite cannot replace a real gate run; no parallel player or checkpoint substitute may bypass it. Historical missing evidence must be disclosed, not fabricated.
