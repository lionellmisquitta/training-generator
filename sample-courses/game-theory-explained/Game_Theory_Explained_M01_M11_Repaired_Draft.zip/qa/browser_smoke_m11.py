"""Partial headless Chromium DOM/interface smoke test; not publication browser QA."""
import hashlib,json,pathlib
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1]
path=root/'course.html'; sha=hashlib.sha256(path.read_bytes()).hexdigest()
checks=[];errors=[]
def record(name,cond,detail=''):
    checks.append({'check':name,'result':'pass' if cond else 'fail','evidence':str(detail)[:500]})
    if not cond: errors.append(name)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1400,'height':900},accept_downloads=True)
 page.on('pageerror',lambda ex: errors.append('JS: '+str(ex)))
 page.set_content(path.read_text(encoding='utf-8'),wait_until='load')
 try:
  record('Course header loaded',page.locator('#courseTitle').inner_text().startswith('Game Theory Explained'),page.locator('#courseTitle').inner_text())
  record('First lesson visible',page.locator('h1').first.inner_text()=='What Makes a Decision Strategic?')
  visited=[]
  for j in range(22):
   heading=page.locator('h1').first.inner_text();visited.append(heading)
   if j<21: page.locator('#following').click()
  record('All 22 lessons reachable by Next',len(set(visited))==22,'last='+visited[-1])
  record('Module 10 L1 in route', 'Bounded Rationality and Fairness' in visited)
  record('Module 10 L2 in route', 'Evolution, Conventions and Coordination' in visited)
  record('Module 11 L1 in route', 'Building and Testing a Strategic Game' in visited)
  record('Module 11 L2 in route', 'Capstone: Partnership, Procurement and Negotiation' in visited)
  record('Last lesson capstone',page.locator('h1').first.inner_text()=='Capstone: Partnership, Procurement and Negotiation')
  apptext=page.locator('#practical-application').inner_text()
  record('Distinct hold-up case rendered', 'hold-up' in apptext.lower() and 'investment' in apptext.lower(),apptext[:200])
  record('Three lesson-specific references on capstone',page.locator('#resourceLinks a').count()==3)
  record('Capstone prompts and options present','High suppliers' in page.locator('body').inner_text() and 'verification' in page.locator('body').inner_text())
  page.locator('#practiceBtn').click()
  record('Practice switch enters exercise mode','isPractice' in page.locator('#app').get_attribute('class'))
  page.locator('#practiceBtn').click()
  record('Practice switch returns to lesson','isPractice' not in page.locator('#app').get_attribute('class'))
  page.locator('#resourceBtn').click()
  record('Resource side pane collapses','hideRight' in page.locator('#app').get_attribute('class'))
  page.locator('#resourceBtn').click()
  record('Resource side pane reopens','hideRight' not in page.locator('#app').get_attribute('class'))
  page.locator('#previous').click()
  record('Previous returns to capstone lesson 1',page.locator('h1').first.inner_text()=='Building and Testing a Strategic Game')
  record('Congestion application rendered','Peak' in page.locator('#practical-application').inner_text())
  page.locator('#previous').click()
  record('Previous reaches evolutionary lesson',page.locator('h1').first.inner_text()=='Evolution, Conventions and Coordination')
  page.screenshot(path=str(root/'evidence/browser-22-desktop.png'),full_page=False)
  mobile=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
  mobile.on('pageerror',lambda ex:errors.append('Mobile JS: '+str(ex)))
  mobile.set_content(path.read_text(encoding='utf-8'),wait_until='load')
  record('390px mobile viewport renders a lesson',mobile.locator('h1').first.is_visible(),mobile.locator('h1').first.inner_text())
  mobile.screenshot(path=str(root/'evidence/browser-22-mobile.png'),full_page=False)
 except Exception as exc:
  errors.append('Browser smoke crash: '+repr(exc))
 b.close()
report={'result':'pass' if not errors else 'fail','test_type':'partial DOM interaction smoke; not publication browser QA','tested_by':'ChatGPT using Chromium headless Playwright','player_sha256':sha,'checks':checks,'errors':errors,'limitations':['The player HTML was inserted with set_content because direct local-file execution was blocked in this environment','This is not a genuine end-user offline local file test; offline storage, native speech and accessibility need full browser acceptance','No external independent educational review or human approval has occurred']}
(root/'BROWSER_SMOKE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(report['result'],len(checks),'checks; errors:',errors)
