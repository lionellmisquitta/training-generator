# Independent retest handoff — final content repairs

Please inspect the `modules/m09.json`, `m10.json`, and `m11.json` files and provide new independent review JSON records bound to their current SHA-256 values. **Do not reuse your previous M09–M11 review hashes.** The old reviews are in `historical-evidence`.

## New module hashes

- `m09`: `ea0ca6db586c0393245d9e8e3b5b0ade66646e69644950028cead0ead7f77519`
- `m10`: `fcac387688b9fa96c0783fc8f7d3ae0af4a83ec67fbb6b955655fdcf9dfff143`
- `m11`: `57bd12844f8df375478ece8f73c793a5ad5566d64c6df6366e06c4debfb3651c`

## Adversarial checks requested

1. Verify M09's sole fixed entry cost of 800 and all subsequent entrant profits.
2. Execute M10 L1 and L2 code blocks; separately recompute 0.8, 2/3, x*=0.6, gradients +/- values, 4/7 and new 0.40 threshold. Falsify the compatibility-bridge scenario for x=0.3 and x=0.5.
3. Execute M11 L1 generic 2x2 solver; confirm pure cells, p=3/8, q=2/3, audit cost shock q=1/2. Confirm M03 L2 reuse is explicitly acknowledged.
4. Execute M11 L2 payoff assertions under b=70, 76 and imperfect 0.90 verification. Confirm incentive compatibility and participation are distinct.
5. Recompute the complete changed modules' mathematical claims, quiz keys, objectives, semantic distinctness, source access labels and UI behavior. Inspect whether the four new code blocks integrate naturally into the lesson player.
6. Re-run `release_gate.py --phase draft` on the entire course. Do not claim publish readiness; the publication gate deliberately fails.

Do not mark a modified module as independently reviewed until checking its new content. Browser QA has not been performed for this final player.
